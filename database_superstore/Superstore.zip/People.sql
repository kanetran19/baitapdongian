CREATE TABLE IF NOT EXISTS People (
    `Person` VARCHAR(17) CHARACTER SET utf8,
    `Region` VARCHAR(7) CHARACTER SET utf8
);
INSERT INTO People VALUES
    ('Anna Andreadi','West'),
    ('Chuck Magee','East'),
    ('Kelly Williams','Central'),
    ('Cassandra Brandow','South');
